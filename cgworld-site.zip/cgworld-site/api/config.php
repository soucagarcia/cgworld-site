<?php
/* =====================================================================
   CGWORLD | configuração do formulário de contato
   Edite somente os valores entre aspas.
   ===================================================================== */

// E-mail que vai RECEBER os contatos do site.
// Exemplo: 'contato@cgworld.app.br'. Se ficar vazio, os contatos são
// apenas gravados no arquivo de registros (veja DADOS_DIR abaixo).
const EMAIL_DESTINO = '';

// Remetente técnico das notificações. Use um e-mail do SEU domínio
// (pode ser um endereço que não recebe mensagens). Isso reduz o risco
// de a notificação cair no spam.
const EMAIL_REMETENTE = 'nao-responda@cgworld.app.br';

// Endereços autorizados a enviar o formulário (além do próprio domínio
// em que o site estiver hospedado, que é sempre aceito).
const ORIGENS_PERMITIDAS = ['https://cgworld.app.br', 'https://www.cgworld.app.br'];

// Pasta onde os contatos são gravados (um arquivo .csv que abre no Excel).
// Recomendado: uma pasta FORA da pasta pública, por exemplo:
//   dirname(__DIR__, 2) . '/cgworld-contatos'
// O padrão abaixo fica dentro do site, protegido pelo arquivo .htaccess.
define('DADOS_DIR', __DIR__ . '/dados');

// Limite de envios por visitante (proteção contra abuso).
const LIMITE_ENVIOS = 5;          // envios
const LIMITE_JANELA_SEG = 600;    // por 10 minutos
