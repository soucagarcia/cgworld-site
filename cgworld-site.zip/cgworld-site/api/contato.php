<?php
/* =====================================================================
   CGWORLD | recebimento do formulário de contato
   Recebe JSON (POST) do site, valida, grava em CSV e envia por e-mail.
   Requer PHP 7.4 ou superior (padrão nas hospedagens com cPanel).
   ===================================================================== */
declare(strict_types=1);
require __DIR__ . '/config.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

function responder(int $codigo, array $dados): void {
    http_response_code($codigo);
    echo json_encode($dados, JSON_UNESCAPED_UNICODE);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    responder(405, ['ok' => false, 'erro' => 'Método não permitido.']);
}

/* Origem da requisição */
$origem = $_SERVER['HTTP_ORIGIN'] ?? '';
if ($origem !== '') {
    $hostOrigem = parse_url($origem, PHP_URL_HOST) ?: '';
    $hostAtual  = preg_replace('/:\d+$/', '', $_SERVER['HTTP_HOST'] ?? '');
    if ($hostOrigem !== $hostAtual && !in_array($origem, ORIGENS_PERMITIDAS, true)) {
        responder(403, ['ok' => false, 'erro' => 'Origem não autorizada.']);
    }
}

/* Leitura do corpo */
$bruto = file_get_contents('php://input', false, null, 0, 30000);
$d = json_decode($bruto ?: '', true);
if (!is_array($d)) {
    responder(400, ['ok' => false, 'erro' => 'Dados inválidos.']);
}

function texto(array $d, string $k, int $max): string {
    $v = isset($d[$k]) && is_scalar($d[$k]) ? trim((string) $d[$k]) : '';
    $v = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $v) ?? '';
    return mb_substr($v, 0, $max);
}
function linha(string $v): string { return trim(preg_replace('/[\r\n]+/', ' ', $v) ?? ''); }

$c = [
    'perfil'      => linha(texto($d, 'perfil', 80)),
    'empresa'     => linha(texto($d, 'empresa', 120)),
    'responsavel' => linha(texto($d, 'responsavel', 120)),
    'email'       => linha(texto($d, 'email', 160)),
    'telefone'    => linha(texto($d, 'telefone', 20)),
    'segmento'    => linha(texto($d, 'segmento', 80)),
    'necessidade' => linha(texto($d, 'necessidade', 120)),
    'mensagem'    => texto($d, 'mensagem', 3000),
];

/* Validação (mesmas regras do site) */
$erros = [];
$perfis = ['Pessoa física ou profissional autônomo','MEI ou microempreendedor','Pequena empresa','Média empresa','Grande empresa'];
if (!in_array($c['perfil'], $perfis, true)) $erros[] = 'perfil';
if (in_array($c['perfil'], ['Pequena empresa','Média empresa','Grande empresa'], true) && mb_strlen($c['empresa']) < 2) $erros[] = 'empresa';
if (mb_strlen($c['responsavel']) < 3)  $erros[] = 'responsavel';
if (!filter_var($c['email'], FILTER_VALIDATE_EMAIL)) $erros[] = 'email';
$digitos = preg_replace('/\D/', '', $c['telefone']) ?? '';
if (strlen($digitos) < 10 || strlen($digitos) > 11) $erros[] = 'telefone';
if ($c['necessidade'] === '')          $erros[] = 'necessidade';
if (mb_strlen($c['mensagem']) < 15)    $erros[] = 'mensagem';
if (($d['consentimento'] ?? false) !== true) $erros[] = 'consentimento';
if ($erros) {
    responder(422, ['ok' => false, 'erro' => 'Verifique os campos.', 'campos' => $erros]);
}

/* Origem da visita (UTM / indicação) */
$utmChaves = ['utm_source','utm_medium','utm_campaign','utm_term','utm_content','ref','parceiro','indicacao'];
function parametros($toque, array $chaves): array {
    $p = (is_array($toque) && isset($toque['params']) && is_array($toque['params'])) ? $toque['params'] : [];
    $r = [];
    foreach ($chaves as $k) { $r[$k] = isset($p[$k]) && is_scalar($p[$k]) ? linha(mb_substr((string) $p[$k], 0, 150)) : ''; }
    return $r;
}
$origemDados = is_array($d['origem'] ?? null) ? $d['origem'] : [];
$ultimo   = parametros($origemDados['last_touch'] ?? null, $utmChaves);
$primeiro = parametros($origemDados['first_touch'] ?? null, $utmChaves);
$referrer = linha(mb_substr((string) ($origemDados['last_touch']['referrer'] ?? ''), 0, 300));
$entrada  = linha(mb_substr((string) ($origemDados['first_touch']['landing_page'] ?? ''), 0, 300));
$resumoOrigem = linha(texto($d, 'origem_resumo', 200)) ?: '(direto)';

/* Pasta de dados + limite de envios */
if (!is_dir(DADOS_DIR)) { @mkdir(DADOS_DIR, 0750, true); }
$ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
$arqLimite = DADOS_DIR . '/limite.json';
$agora = time();
$limites = [];
if (is_file($arqLimite)) { $limites = json_decode((string) @file_get_contents($arqLimite), true) ?: []; }
$chaveIp = hash('sha256', $ip);
$hist = array_values(array_filter($limites[$chaveIp] ?? [], fn($t) => $t > $agora - LIMITE_JANELA_SEG));
if (count($hist) >= LIMITE_ENVIOS) {
    responder(429, ['ok' => false, 'erro' => 'Muitos envios em pouco tempo. Tente novamente mais tarde.']);
}
$hist[] = $agora;
$limites[$chaveIp] = $hist;
foreach ($limites as $k => $v) { if (max($v) < $agora - LIMITE_JANELA_SEG) unset($limites[$k]); }
@file_put_contents($arqLimite, json_encode($limites), LOCK_EX);

/* 1) Gravação em CSV (abre no Excel) */
$data = (new DateTime('now', new DateTimeZone('America/Sao_Paulo')))->format('d/m/Y H:i');
$registro = [
    $data, $c['perfil'], $c['responsavel'], $c['empresa'], $c['email'], $c['telefone'], $c['segmento'],
    $c['necessidade'], $c['mensagem'], $resumoOrigem,
    $ultimo['utm_source'], $ultimo['utm_medium'], $ultimo['utm_campaign'], $ultimo['utm_term'], $ultimo['utm_content'],
    $ultimo['ref'] ?: ($ultimo['parceiro'] ?: $ultimo['indicacao']),
    $primeiro['utm_source'], $primeiro['utm_medium'], $primeiro['utm_campaign'],
    $referrer, $entrada,
];
$registro = array_map(fn($v) => preg_match('/^[=+\-@\t]/', (string) $v) ? "'" . $v : $v, $registro);
$nomeArquivo = 'contatos-' . substr(hash('sha256', __DIR__ . (php_uname('n') ?: '')), 0, 16) . '.csv';
$arquivo = DADOS_DIR . '/' . $nomeArquivo;
$novo = !is_file($arquivo);
$gravou = false;
if ($fp = @fopen($arquivo, 'a')) {
    if (flock($fp, LOCK_EX)) {
        if ($novo) {
            fwrite($fp, "\xEF\xBB\xBF");
            fputcsv($fp, ['Data','Perfil','Nome','Empresa','E-mail','Telefone','Segmento','Necessidade','Mensagem','Origem (resumo)',
                'utm_source','utm_medium','utm_campaign','utm_term','utm_content','ref/parceiro',
                'utm_source (1º acesso)','utm_medium (1º acesso)','utm_campaign (1º acesso)','Referência','Página de entrada'], ';');
        }
        $gravou = fputcsv($fp, $registro, ';') !== false;
        flock($fp, LOCK_UN);
    }
    fclose($fp);
}

/* 2) Notificação por e-mail */
$enviou = false;
if (EMAIL_DESTINO !== '' && filter_var(EMAIL_DESTINO, FILTER_VALIDATE_EMAIL)) {
    $assunto = 'Novo contato pelo site: ' . ($c['empresa'] !== '' ? $c['empresa'] : $c['responsavel']);
    $corpo = "Novo contato recebido pelo site CGWORLD em {$data}.\n\n"
        . "Perfil: {$c['perfil']}\nNome: {$c['responsavel']}\n"
        . 'Empresa: ' . ($c['empresa'] ?: 'Não informado') . "\n"
        . "E-mail: {$c['email']}\nTelefone: {$c['telefone']}\n"
        . 'Segmento: ' . ($c['segmento'] ?: 'Não informado') . "\n"
        . "Necessidade: {$c['necessidade']}\n\nProjeto:\n{$c['mensagem']}\n\n"
        . "Origem: {$resumoOrigem}\n"
        . ($ultimo['utm_source'] ? "utm_source: {$ultimo['utm_source']}\n" : '')
        . ($ultimo['utm_medium'] ? "utm_medium: {$ultimo['utm_medium']}\n" : '')
        . ($ultimo['utm_campaign'] ? "utm_campaign: {$ultimo['utm_campaign']}\n" : '')
        . ($referrer ? "Referência: {$referrer}\n" : '');
    $cab = [
        'MIME-Version: 1.0',
        'Content-Type: text/plain; charset=UTF-8',
        'Content-Transfer-Encoding: 8bit',
        'From: CGWORLD Site <' . EMAIL_REMETENTE . '>',
        'Reply-To: ' . $c['email'],
        'X-Mailer: CGWORLD',
    ];
    $assuntoCod = '=?UTF-8?B?' . base64_encode($assunto) . '?=';
    $enviou = @mail(EMAIL_DESTINO, $assuntoCod, $corpo, implode("\r\n", $cab), '-f' . EMAIL_REMETENTE);
    if (!$enviou) {
        $enviou = @mail(EMAIL_DESTINO, $assuntoCod, $corpo, implode("\r\n", $cab));
    }
}

if (!$gravou && !$enviou) {
    error_log('CGWORLD contato: falha ao gravar e ao enviar e-mail. Verifique permissões de ' . DADOS_DIR . ' e o envio de e-mails da hospedagem.');
    responder(500, ['ok' => false, 'erro' => 'Não foi possível registrar o contato.']);
}
responder(200, ['ok' => true]);
