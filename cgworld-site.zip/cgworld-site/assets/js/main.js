/* =====================================================================
   CONFIGURAÇÃO: ajuste antes de publicar
   ---------------------------------------------------------------------
   email:        e-mail comercial exibido no site. Vazio = oculto.
   formEndpoint: URL que recebe o formulário em JSON (POST). Padrão: o
                 script PHP incluído no projeto (api/contato.php).
                 Alternativas:
                 Compatível com webhook do n8n / Make / Zapier, Formspree,
                 Web3Forms, Google Apps Script, Supabase Edge Function ou
                 API própria. Vazio = o formulário valida os dados e
                 conduz o envio pelo WhatsApp (nada é enviado em silêncio).
   ===================================================================== */
const CONFIG = {
  whatsapp: '5511957042065',
  email: '',
  formEndpoint: 'api/contato.php',
  endpointHeaders: {},
  waDefaultText: 'Olá! Conheci a CGWORLD e gostaria de conversar sobre um projeto.'
};

(function(){
'use strict';
document.documentElement.classList.add('js');
const reduce=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const fine=window.matchMedia('(hover:hover) and (pointer:fine)').matches;
const $=(s,c=document)=>c.querySelector(s), $$=(s,c=document)=>[...c.querySelectorAll(s)];
const store={get(t,k){try{return JSON.parse(window[t].getItem(k)||'null')}catch(e){return null}},set(t,k,v){try{window[t].setItem(k,JSON.stringify(v))}catch(e){}}};
$('#yr').textContent=new Date().getFullYear();

/* ---------- E-mail (opcional) ---------- */
if(CONFIG.email){
  $$('.em-txt').forEach(s=>s.textContent=CONFIG.email);
  $$('.em-link').forEach(a=>{a.href='mailto:'+CONFIG.email;a.hidden=false});
  $$('.em-li').forEach(l=>l.hidden=false);
}

/* ---------- Origem / UTM ---------- */
const TRACK_KEYS=['utm_source','utm_medium','utm_campaign','utm_term','utm_content','ref','parceiro','indicacao','gclid','fbclid'];
const tracking=(function(){
  let qs; try{qs=new URLSearchParams(location.search)}catch(e){qs=new URLSearchParams()}
  const params={}; TRACK_KEYS.forEach(k=>{const v=qs.get(k); if(v) params[k]=String(v).slice(0,150)});
  const touch={params,landing_page:location.href.split('#')[0],referrer:document.referrer||'(direto)',captured_at:new Date().toISOString()};
  let first=store.get('localStorage','cgw_first_touch');
  if(!first){first=touch;store.set('localStorage','cgw_first_touch',touch)}
  let last=store.get('sessionStorage','cgw_last_touch');
  if(Object.keys(params).length||!last){last=touch;store.set('sessionStorage','cgw_last_touch',touch)}
  return {first_touch:first,last_touch:last};
})();
function originLabel(){
  const p=(tracking.last_touch&&tracking.last_touch.params)||{};
  return [p.utm_source||p.parceiro||p.ref,p.utm_medium,p.utm_campaign].filter(Boolean).join(' / ');
}
const ol=originLabel();
function waUrl(text){return 'https://wa.me/'+CONFIG.whatsapp+'?text='+encodeURIComponent(text)}
$$('.wa-link').forEach(a=>{a.href=waUrl(CONFIG.waDefaultText+(ol?'\n(Ref.: '+ol+')':''))});
window.CGW_TRACKING=tracking;

/* ---------- Header, progress, active nav ---------- */
const hdr=$('#hdr'), prog=$('#progress'), waF=$('#waFloat'), contact=$('#contato');
const navLinks=$$('.nav a');
let ticking=false;
function onScroll(){
  const y=scrollY, max=document.documentElement.scrollHeight-innerHeight;
  hdr.classList.toggle('solid',y>24||dr.classList.contains('open'));
  prog.style.transform='scaleX('+(max>0?y/max:0)+')';
  waF.classList.toggle('show',y>innerHeight*.8&&contact.getBoundingClientRect().top>innerHeight*.6);
  journeyScroll();
  ticking=false;
}
addEventListener('scroll',()=>{if(!ticking){ticking=true;requestAnimationFrame(onScroll)}},{passive:true});
const secObs=new IntersectionObserver(es=>{es.forEach(e=>{if(e.isIntersecting){navLinks.forEach(a=>a.classList.toggle('active',a.getAttribute('href')==='#'+e.target.id))}})},{rootMargin:'-45% 0px -50% 0px'});
['o-que-fazemos','segmentos','desafios','metodo','na-pratica','diferenciais','contato'].forEach(id=>secObs.observe(document.getElementById(id)));

/* ---------- Mobile menu ---------- */
const mb=$('#menuBtn'), dr=$('#drawer');
function setMenu(open){mb.setAttribute('aria-expanded',open);mb.setAttribute('aria-label',open?'Fechar menu':'Abrir menu');dr.classList.toggle('open',open);document.body.style.overflow=open?'hidden':'';hdr.classList.toggle('solid',open||scrollY>24)}
mb.addEventListener('click',()=>setMenu(mb.getAttribute('aria-expanded')!=='true'));
$$('a',dr).forEach(a=>a.addEventListener('click',()=>setMenu(false)));
addEventListener('keydown',e=>{if(e.key==='Escape'&&dr.classList.contains('open')){setMenu(false);mb.focus()}});
addEventListener('resize',()=>{if(innerWidth>1240&&dr.classList.contains('open'))setMenu(false)});

/* ---------- CTA pré-seleciona a necessidade ---------- */
$$('[data-need]').forEach(a=>a.addEventListener('click',()=>{const s=$('#f-nec');if(s)s.value=a.dataset.need}));
$$('[data-seg]').forEach(a=>a.addEventListener('click',()=>{const s=$('#f-seg');if(s)s.value=a.dataset.seg;const n=$('#f-nec');if(n&&!n.value)n.value='Quero conhecer as soluções prontas do portfólio'}));

/* ---------- Reveal ---------- */
if(!reduce&&'IntersectionObserver' in window){
  const ro=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');ro.unobserve(e.target)}}),{rootMargin:'0px 0px -8% 0px',threshold:.08});
  $$('.rv').forEach(el=>ro.observe(el));
}else{$$('.rv').forEach(el=>el.classList.add('in'))}

/* ---------- Pointer effects ---------- */
const hero=$('.hero');
if(fine&&!reduce){
  hero.addEventListener('pointermove',e=>{const r=hero.getBoundingClientRect();hero.style.setProperty('--mx',(e.clientX-r.left)+'px');hero.style.setProperty('--my',(e.clientY-r.top)+'px')});
  $$('.tilt').forEach(c=>{
    c.addEventListener('pointermove',e=>{const r=c.getBoundingClientRect(),px=(e.clientX-r.left)/r.width,py=(e.clientY-r.top)/r.height;c.style.setProperty('--ry',((px-.5)*6)+'deg');c.style.setProperty('--rx',((.5-py)*6)+'deg');c.style.setProperty('--gx',px*100+'%');c.style.setProperty('--gy',py*100+'%')});
    c.addEventListener('pointerleave',()=>{c.style.setProperty('--rx','0deg');c.style.setProperty('--ry','0deg')});
  });
  $$('.mag').forEach(b=>{
    b.addEventListener('pointermove',e=>{const r=b.getBoundingClientRect();b.style.setProperty('--bx',((e.clientX-r.left-r.width/2)*.12)+'px');b.style.setProperty('--by',((e.clientY-r.top-r.height/2)*.2)+'px')});
    b.addEventListener('pointerleave',()=>{b.style.setProperty('--bx','0px');b.style.setProperty('--by','0px')});
  });
}

/* ---------- Combos ---------- */
const fronts=$('#fronts'), comboOut=$('#comboOut');
$$('.combo').forEach(btn=>btn.addEventListener('click',()=>{
  const on=btn.getAttribute('aria-pressed')!=='true';
  $$('.combo').forEach(b=>b.setAttribute('aria-pressed','false'));
  $$('.front').forEach(f=>f.classList.remove('hl'));
  if(on){btn.setAttribute('aria-pressed','true');fronts.classList.add('focus');btn.dataset.f.split(' ').forEach(k=>{const f=$('.front[data-front="'+k+'"]');if(f)f.classList.add('hl')});comboOut.textContent=btn.dataset.t}
  else{fronts.classList.remove('focus');comboOut.textContent=''}
}));

/* ---------- Problems ---------- */
$$('.prob').forEach(p=>p.addEventListener('click',()=>{const o=p.getAttribute('aria-expanded')==='true';p.setAttribute('aria-expanded',String(!o))}));
if(!fine){const h=$('.hint-hover');if(h)h.textContent='Toque em cada card para ver como abordamos.'}

/* ---------- Para quem: seletor de perfil ---------- */
(function(){
  const box=$('.aud'), tabs=$$('.size'), panels=$$('.size-p'), scale=$('.size-scale'); if(!box||!tabs.length)return;
  let cur=0, auto=!reduce, vis=false, timer=null;
  function sel(n,focus){cur=n;tabs.forEach((t,k)=>{t.setAttribute('aria-selected',String(k===n));t.tabIndex=k===n?0:-1});panels.forEach((p,k)=>{p.hidden=k!==n});scale.style.setProperty('--f',(n+1)/tabs.length);if(focus)tabs[n].focus()}
  function run(){clearInterval(timer);if(auto&&vis&&!document.hidden)timer=setInterval(()=>sel((cur+1)%tabs.length),4200)}
  function stop(){auto=false;clearInterval(timer)}
  tabs.forEach((t,k)=>{t.addEventListener('click',()=>{stop();sel(k)});t.addEventListener('keydown',e=>{let n=null;if(e.key==='ArrowRight'||e.key==='ArrowDown')n=(k+1)%tabs.length;if(e.key==='ArrowLeft'||e.key==='ArrowUp')n=(k+tabs.length-1)%tabs.length;if(n!==null){e.preventDefault();stop();sel(n,true)}})});
  box.addEventListener('pointerenter',()=>clearInterval(timer));box.addEventListener('pointerleave',run);box.addEventListener('focusin',stop);
  new IntersectionObserver(es=>{vis=es[0].isIntersecting;run()},{threshold:.35}).observe(box);
  document.addEventListener('visibilitychange',run);
  sel(0);
})();
$$('[data-perfil]').forEach(a=>a.addEventListener('click',()=>{const r=$('input[name="perfil"][value="'+a.dataset.perfil+'"]');if(r){r.checked=true;r.dispatchEvent(new Event('change',{bubbles:true}))}}));

/* ---------- Segmentos: explorador ---------- */
(function(){
  const view=$('.segx-view'), btns=$$('.sx'); let data=[]; try{data=JSON.parse($('#segData').textContent)}catch(e){}
  if(!view||!btns.length||!data.length)return;
  const body=$('#svBody'), name=$('.sv-name',view), slug=$('.sv-slug',view), cta=$('.sv-cta',view), DUR=5200;
  let cur=0, auto=!reduce, vis=false, timer=null;
  view.style.setProperty('--dur',DUR+'ms');
  function sel(n,focus){
    cur=n; const d=data[n];
    btns.forEach((b,k)=>{b.setAttribute('aria-selected',String(k===n));b.tabIndex=k===n?0:-1});
    name.textContent=d.n; slug.textContent='portfolio/'+d.s; cta.dataset.seg=d.n;
    d.t.forEach((t,k)=>{const a=$('.sv-t'+k,view),b=$('.sv-k'+k,view);if(a)a.textContent=t;if(b)b.textContent=t});
    body.classList.remove('sv-swap'); void body.offsetWidth; body.classList.add('sv-swap');
    $$('.sv-tile path,.sv-rows i,.sv-mi',view).forEach(el=>{el.style.animation='none';void el.offsetWidth;el.style.animation=''});
    if(focus){btns[n].focus({preventScroll:true});btns[n].scrollIntoView({block:'nearest',inline:'nearest',behavior:reduce?'auto':'smooth'})}
    progress();
  }
  function progress(){view.classList.remove('sv-run');void view.offsetWidth;if(auto&&vis&&!document.hidden)view.classList.add('sv-run')}
  function run(){clearInterval(timer);progress();if(auto&&vis&&!document.hidden)timer=setInterval(()=>sel((cur+1)%data.length),DUR)}
  function stop(){auto=false;clearInterval(timer);view.classList.remove('sv-run')}
  btns.forEach((b,k)=>{b.addEventListener('click',()=>{stop();sel(k)});b.addEventListener('keydown',e=>{let n=null;if(e.key==='ArrowRight'||e.key==='ArrowDown')n=(k+1)%btns.length;if(e.key==='ArrowLeft'||e.key==='ArrowUp')n=(k+btns.length-1)%btns.length;if(n!==null){e.preventDefault();stop();sel(n,true)}})});
  const wrap=$('.segx'); wrap.addEventListener('pointerenter',()=>{clearInterval(timer);view.classList.remove('sv-run')});wrap.addEventListener('pointerleave',run);wrap.addEventListener('focusin',stop);
  new IntersectionObserver(es=>{vis=es[0].isIntersecting;run()},{threshold:.3}).observe(wrap);
  document.addEventListener('visibilitychange',run);
  sel(0);
})();

/* ---------- Journey ---------- */
const jSec=$('#metodo'), jTrack=$('#jTrack'), jLineWrap=$('#jLine').parentElement, jSteps=$$('.j-step'), jPanes=$$('.j-pane');
let jIdx=0;
const scrollyMQ=window.matchMedia('(min-width: 861px)');
function scrolly(){return scrollyMQ.matches&&!reduce}
function jActivate(i,focus){
  const changed=i!==jIdx; jIdx=i;
  jSteps.forEach((s,k)=>{s.classList.toggle('on',k===i);s.classList.toggle('done',k<i);s.setAttribute('aria-selected',String(k===i));s.tabIndex=k===i?0:-1});
  if(changed||focus!==undefined)jPanes.forEach((p,k)=>{p.hidden=k!==i});
  if(!scrolly())jLineWrap.style.setProperty('--p',i/4);
  if(focus)jSteps[i].focus({preventScroll:scrolly()});
}
function journeyScroll(){
  if(!scrolly())return;
  const r=jTrack.getBoundingClientRect(), total=jTrack.offsetHeight-innerHeight;
  const p=Math.min(1,Math.max(0,-r.top/total));
  jLineWrap.style.setProperty('--p',p);
  const i=Math.min(4,Math.floor(p*5));
  if(i!==jIdx)jActivate(i);
}
function setScrolly(){jSec.classList.toggle('scrolly',scrolly());jActivate(jIdx,false);journeyScroll()}
function jGo(i){
  if(scrolly()){const top=jTrack.getBoundingClientRect().top+scrollY,total=jTrack.offsetHeight-innerHeight;scrollTo({top:top+total*((i+.5)/5),behavior:'smooth'})}
  jActivate(i);
}
jSteps.forEach((s,i)=>{
  s.addEventListener('click',()=>jGo(i));
  s.addEventListener('keydown',e=>{
    let n=null; if(e.key==='ArrowRight'||e.key==='ArrowDown')n=(i+1)%5; if(e.key==='ArrowLeft'||e.key==='ArrowUp')n=(i+4)%5;
    if(n!==null){e.preventDefault();jGo(n);jSteps[n].focus({preventScroll:scrolly()})}
  });
});
if(scrollyMQ.addEventListener)scrollyMQ.addEventListener('change',setScrolly);else scrollyMQ.addListener(setScrolly);
setScrolly();

/* ---------- Demos ---------- */
const dTabs=$$('.d-tab'), dPanels=$$('.d-panel'), dTitle=$('#dTitle');
const dNames=['assistente-ia','automacao-de-vendas','crm-inteligente','dashboard-gerencial','integracao-de-processos','sistema-personalizado'];
let dLoop=null, dActive=0, dVisible=false;
function svgs(p,fn){$$('svg',p).forEach(s=>{if(s.pauseAnimations){try{fn(s)}catch(e){}}})}
function play(panel){
  panel.classList.remove('play'); void panel.offsetWidth; panel.classList.add('play');
  svgs(panel,s=>{s.setCurrentTime(0);s.unpauseAnimations()});
}
function runDemo(){
  clearInterval(dLoop); const p=dPanels[dActive];
  if(reduce){p.classList.add('play');svgs(p,s=>s.pauseAnimations());return}
  if(!dVisible){svgs(p,s=>s.pauseAnimations());return}
  play(p); dLoop=setInterval(()=>play(p),+p.dataset.loop||8000);
}
function selectDemo(i,focus){
  dActive=i;
  dTabs.forEach((t,k)=>{t.setAttribute('aria-selected',String(k===i));t.tabIndex=k===i?0:-1});
  dPanels.forEach((p,k)=>{const on=k===i;p.hidden=!on;if(!on){p.classList.remove('play');svgs(p,s=>s.pauseAnimations())}});
  dTitle.textContent=dNames[i];
  if(focus){dTabs[i].focus({preventScroll:true});dTabs[i].scrollIntoView({block:'nearest',inline:'nearest',behavior:reduce?'auto':'smooth'})}
  runDemo();
}
dTabs.forEach((t,i)=>{
  t.addEventListener('click',()=>selectDemo(i));
  t.addEventListener('keydown',e=>{let n=null;if(e.key==='ArrowDown'||e.key==='ArrowRight')n=(i+1)%6;if(e.key==='ArrowUp'||e.key==='ArrowLeft')n=(i+5)%6;if(n!==null){e.preventDefault();selectDemo(n,true)}});
});
new IntersectionObserver(es=>es.forEach(e=>{dVisible=e.isIntersecting;if(dVisible)runDemo();else{clearInterval(dLoop);svgs(dPanels[dActive],s=>s.pauseAnimations())}}),{threshold:.2}).observe($('#dStage'));
document.addEventListener('visibilitychange',()=>{if(document.hidden)clearInterval(dLoop);else if(dVisible)runDemo()});
selectDemo(0);
if(reduce)$$('.howflow svg').forEach(v=>{try{v.pauseAnimations()}catch(e){}});

/* ---------- Hero scene (canvas 3D) ---------- */
(function scene(){
  const cv=$('#scene'); if(!cv||!cv.getContext)return;
  const ctx=cv.getContext('2d');
  const labels=['Processos','Sistemas','IA','Integrações','Soluções','Automação','Aplicativos','Dashboards'];
  const nodes=labels.map((l,i)=>({l,a:i/labels.length*Math.PI*2}));
  const dust=Array.from({length:90},()=>({a:Math.random()*Math.PI*2,r:.5+Math.random()*.75,y:(Math.random()-.5)*.9,s:(.04+Math.random()*.12)*(Math.random()<.5?-1:1)}));
  let W=0,H=0,R=0,cx=0,cy=0,dpr=1,t=0.6,mx=0,my=0,tmx=0,tmy=0,raf=0,visible=true,last=0;
  function size(){const b=cv.getBoundingClientRect();dpr=Math.min(2,window.devicePixelRatio||1);W=b.width;H=b.height;cv.width=Math.round(W*dpr);cv.height=Math.round(H*dpr);ctx.setTransform(dpr,0,0,dpr,0,0);cx=W/2;cy=H/2;R=Math.min(W,H)*.38}
  function proj(x,y,z){
    const tilt=.36+my*.12, rot=mx*.35;
    const x1=x*Math.cos(rot)-z*Math.sin(rot), z1=x*Math.sin(rot)+z*Math.cos(rot);
    const y1=y*Math.cos(tilt)-z1*Math.sin(tilt), z2=y*Math.sin(tilt)+z1*Math.cos(tilt);
    const f=3.4/(3.4+z2); return {x:cx+x1*R*f,y:cy+y1*R*f,f,z:z2};
  }
  function line(pts,style){ctx.beginPath();pts.forEach((p,k)=>k?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.strokeStyle=style;ctx.stroke()}
  function globe(){
    const gr=.34; ctx.lineWidth=1;
    for(let m=0;m<10;m++){const ph=m/10*Math.PI+t*.25,pts=[];for(let k=0;k<=40;k++){const th=k/40*Math.PI*2;pts.push(proj(gr*Math.sin(th)*Math.cos(ph),gr*Math.cos(th),gr*Math.sin(th)*Math.sin(ph)))}line(pts,'rgba(255,255,255,.10)')}
    for(let l=1;l<6;l++){const yy=gr*Math.cos(l/6*Math.PI),r2=gr*Math.sin(l/6*Math.PI),pts=[];for(let k=0;k<=48;k++){const th=k/48*Math.PI*2;pts.push(proj(r2*Math.cos(th),yy,r2*Math.sin(th)))}line(pts,'rgba(255,255,255,.08)')}
    const c=proj(0,0,0);
    const g=ctx.createRadialGradient(c.x,c.y,0,c.x,c.y,R*.55);g.addColorStop(0,'rgba(255,255,255,.16)');g.addColorStop(1,'rgba(255,255,255,0)');
    ctx.fillStyle=g;ctx.beginPath();ctx.arc(c.x,c.y,R*.55,0,Math.PI*2);ctx.fill();
    ctx.fillStyle='rgba(255,255,255,.94)';ctx.textAlign='center';ctx.textBaseline='middle';
    let fz=Math.round(R*.1);ctx.font='800 '+fz+'px "Plus Jakarta Sans",sans-serif';
    const maxW=R*.56,tw=ctx.measureText('CGWORLD').width;
    if(tw>maxW){fz=Math.floor(fz*maxW/tw);ctx.font='800 '+fz+'px "Plus Jakarta Sans",sans-serif'}
    ctx.fillText('CGWORLD',c.x,c.y+1);
  }
  function rr(x,y,w,h,r){ctx.beginPath();ctx.moveTo(x+r,y);ctx.arcTo(x+w,y,x+w,y+h,r);ctx.arcTo(x+w,y+h,x,y+h,r);ctx.arcTo(x,y+h,x,y,r);ctx.arcTo(x,y,x+w,y,r);ctx.closePath()}
  function frame(ts){
    const dt=last?Math.min(50,ts-last):16; last=ts;
    if(!reduce)t+=dt*.00018;
    mx+=(tmx-mx)*.05; my+=(tmy-my)*.05;
    ctx.clearRect(0,0,W,H);
    [1,1.22].forEach((rad,ri)=>{const pts=[];for(let k=0;k<=80;k++){const th=k/80*Math.PI*2;pts.push(proj(rad*Math.cos(th),0,rad*Math.sin(th)))}ctx.lineWidth=1;line(pts,ri?'rgba(255,255,255,.05)':'rgba(255,255,255,.12)')});
    dust.forEach(d=>{const a=d.a+t*d.s*6;const p=proj(d.r*1.25*Math.cos(a),d.y*.35,d.r*1.25*Math.sin(a));ctx.fillStyle='rgba(255,255,255,'+(.08+.25*(1-(p.z+1.3)/2.6))+')';ctx.fillRect(p.x,p.y,1.3*p.f,1.3*p.f)});
    const ps=nodes.map((n,i)=>{const a=n.a+t;return Object.assign(proj(Math.cos(a),Math.sin(a*2+i)*.06,Math.sin(a)),{n,i})}).sort((a,b)=>b.z-a.z);
    const center=proj(0,0,0);
    function link(p){
      const al=.06+.16*(1-(p.z+1)/2);
      ctx.strokeStyle='rgba(255,255,255,'+al+')';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(center.x,center.y);ctx.lineTo(p.x,p.y);ctx.stroke();
      const q=((t*1.6+p.i*.37)%1),px=center.x+(p.x-center.x)*q,py=center.y+(p.y-center.y)*q;
      ctx.fillStyle='rgba(255,255,255,'+Math.min(1,al*3.2)+')';ctx.beginPath();ctx.arc(px,py,1.8*p.f,0,Math.PI*2);ctx.fill();
    }
    function node(p){
      const s=p.f, depth=1-(p.z+1)/2, fs=Math.max(10,(W<420?11:12.5)*s);
      ctx.font='600 '+fs+'px "Plus Jakarta Sans",sans-serif';
      const w=ctx.measureText(p.n.l).width+26*s, h=fs+16*s;
      ctx.globalAlpha=.35+.65*depth;
      rr(p.x-w/2,p.y-h/2,w,h,h/2);
      ctx.fillStyle='rgba(18,20,25,.94)';ctx.fill();
      ctx.strokeStyle='rgba(255,255,255,'+(.12+.3*depth)+')';ctx.lineWidth=1;ctx.stroke();
      ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(p.x-w/2+11*s,p.y,2.6*s,0,Math.PI*2);ctx.fill();
      ctx.fillStyle='rgba(245,245,246,'+(.55+.45*depth)+')';ctx.textAlign='left';ctx.textBaseline='middle';ctx.fillText(p.n.l,p.x-w/2+19*s,p.y+.5);
      ctx.globalAlpha=1;
    }
    const back=ps.filter(p=>p.z>0), front=ps.filter(p=>p.z<=0);
    back.forEach(link);back.forEach(node);
    globe();
    front.forEach(link);front.forEach(node);
    if(!reduce&&visible&&!document.hidden)raf=requestAnimationFrame(frame);
  }
  function start(){cancelAnimationFrame(raf);last=0;raf=requestAnimationFrame(frame)}
  size();
  if(document.fonts&&document.fonts.ready)document.fonts.ready.then(()=>{if(reduce)frame(0)});
  if('ResizeObserver' in window)new ResizeObserver(()=>{size();if(reduce)frame(0)}).observe(cv);
  if(reduce){frame(0);return}
  if(fine)addEventListener('pointermove',e=>{tmx=(e.clientX/innerWidth-.5)*2;tmy=(e.clientY/innerHeight-.5)*2},{passive:true});
  new IntersectionObserver(es=>{visible=es[0].isIntersecting;if(visible&&!document.hidden)start();else cancelAnimationFrame(raf)}).observe(cv);
  document.addEventListener('visibilitychange',()=>{if(document.hidden)cancelAnimationFrame(raf);else if(visible)start()});
})();

/* ---------- Form ---------- */
const form=$('#leadForm'), card=$('#formCard'), fStatus=$('#fStatus'), submit=$('#fSubmit'), tel=$('#f-tel');
tel.addEventListener('input',()=>{
  const d=tel.value.replace(/\D/g,'').slice(0,11), cut=d.length===11?7:6;
  let v=d; if(d.length>2)v='('+d.slice(0,2)+') '+d.slice(2); if(d.length>6)v='('+d.slice(0,2)+') '+d.slice(2,cut)+'-'+d.slice(cut);
  tel.value=v;
});
const EMPRESA_OBRIGATORIA=['Pequena empresa','Média empresa','Grande empresa'];
function perfilAtual(){const r=$('input[name="perfil"]:checked');return r?r.value:''}
function empresaObrigatoria(){return EMPRESA_OBRIGATORIA.includes(perfilAtual())}
const rules={
  'f-empresa':v=>!empresaObrigatoria()||v.trim().length>=2||'Informe o nome da empresa.',
  'f-nome':v=>v.trim().length>=3||'Informe o seu nome.',
  'f-email':v=>/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim())||'Informe um e-mail válido.',
  'f-tel':v=>{const d=v.replace(/\D/g,'');return (d.length===10||d.length===11)||'Informe um telefone com DDD.'},
  'f-nec':v=>!!v||'Selecione a principal necessidade.',
  'f-msg':v=>v.trim().length>=15||'Conte um pouco mais sobre o projeto (mínimo de 15 caracteres).'
};
function check(id){
  const el=document.getElementById(id), r=rules[id](el.value), err=document.getElementById(el.getAttribute('aria-describedby'));
  const ok=r===true; el.setAttribute('aria-invalid',String(!ok)); err.textContent=ok?'':r; return ok;
}
Object.keys(rules).forEach(id=>{const el=document.getElementById(id);el.addEventListener('blur',()=>{if(el.value)check(id)});el.addEventListener('input',()=>{if(el.getAttribute('aria-invalid')==='true')check(id)});el.addEventListener('change',()=>{if(el.getAttribute('aria-invalid')==='true')check(id)})});
const okBox=$('#f-ok');
function checkOk(){const ok=okBox.checked;okBox.setAttribute('aria-invalid',String(!ok));$('#e-ok').textContent=ok?'':'É necessário autorizar o contato.';return ok}
okBox.addEventListener('change',checkOk);
const perfilBox=$('#f-perfil'), lEmp=$('#l-empresa'), fEmp=$('#f-empresa');
function checkPerfil(){const ok=!!perfilAtual();perfilBox.setAttribute('aria-invalid',String(!ok));$('#e-perfil').textContent=ok?'':'Selecione o seu perfil.';return ok}
function syncEmpresa(){const req=empresaObrigatoria();fEmp.required=req;lEmp.innerHTML='Nome da empresa '+(req?'*':'<span class="opc">(se houver)</span>');if(!req&&fEmp.getAttribute('aria-invalid')==='true')check('f-empresa')}
$$('input[name="perfil"]').forEach(r=>r.addEventListener('change',()=>{checkPerfil();syncEmpresa()}));
const FIELDS=['perfil','responsavel','empresa','email','telefone','necessidade','segmento','mensagem'];
const draft=store.get('sessionStorage','cgw_form_draft');
if(draft)FIELDS.forEach(k=>{const el=form.elements[k];if(el&&draft[k]&&!el.value)el.value=draft[k]});
syncEmpresa();
form.addEventListener('input',()=>{const d={};FIELDS.forEach(k=>d[k]=form.elements[k].value);store.set('sessionStorage','cgw_form_draft',d)});

function buildSummary(d){
  return ['*Novo contato pelo site CGWORLD*','Perfil: '+d.perfil,'Nome: '+d.responsavel,'Empresa: '+(d.empresa||'Não informado'),'E-mail: '+d.email,'Telefone: '+d.telefone,'Necessidade: '+d.necessidade,'Segmento: '+(d.segmento||'Não informado'),'','Necessidade descrita:',d.mensagem].concat(ol?['','Ref.: '+ol]:[]).join('\n');
}
function setLoading(on){submit.disabled=on;submit.classList.toggle('loading',on);$('#fSubmitTxt').textContent=on?'Enviando…':'Enviar solicitação'}
function mkBtn(tag,cls,txt){const b=document.createElement(tag);b.className='btn '+cls;b.textContent=txt;return b}
function showDone(mode,d){
  const title=$('#doneTitle'), text=$('#doneText'), btns=$('#doneBtns'), sum=$('#doneSummary');
  btns.innerHTML=''; sum.hidden=true;
  const first=(d.responsavel||'').split(' ')[0];
  if(mode==='sent'){
    title.textContent='Solicitação recebida'+(first?', '+first:'')+'.';
    text.textContent='Obrigado pelo contato. Nossa equipe vai analisar o que você descreveu e retornar em até 24 horas pelo e-mail ou telefone informado.';
    if(d.responsavel){const a=mkBtn('a','btn-ghost','Prefere adiantar pelo WhatsApp?');a.href=waUrl(buildSummary(d));a.target='_blank';a.rel='noopener';btns.appendChild(a)}
  }else{
    title.textContent='Quase lá, '+first+'.';
    text.textContent='Seus dados foram validados. Para concluir o envio, abra o WhatsApp: a mensagem já vem preenchida com as informações do formulário.';
    const a=mkBtn('a','btn-primary','Concluir pelo WhatsApp');a.href=waUrl(buildSummary(d));a.target='_blank';a.rel='noopener';btns.appendChild(a);
    const plain=buildSummary(d).replace(/\*/g,'');
    const c=mkBtn('button','btn-ghost','Copiar resumo');c.type='button';
    c.addEventListener('click',async()=>{try{await navigator.clipboard.writeText(plain);c.textContent='Resumo copiado'}catch(e){sum.hidden=false;c.textContent='Copie o texto abaixo'}});
    btns.appendChild(c);
    sum.textContent=plain+(CONFIG.email?'\n\nOu envie por e-mail para '+CONFIG.email:'');
    sum.hidden=false;
  }
  card.classList.add('sent');
  $('#done').focus({preventScroll:true});
  card.scrollIntoView({behavior:reduce?'auto':'smooth',block:'center'});
}
form.addEventListener('submit',async e=>{
  e.preventDefault(); fStatus.textContent='';
  const pOk=checkPerfil(), ids=Object.keys(rules), results=ids.map(check), ok=checkOk();
  const firstBad=ids.find((id,i)=>!results[i]);
  if(!pOk||firstBad||!ok){(pOk?document.getElementById(firstBad||'f-ok'):$('input[name="perfil"]')).focus();fStatus.textContent='Revise os campos destacados.';return}
  if(form.elements.website.value){showDone('sent',{});return}
  const d={};FIELDS.forEach(k=>d[k]=form.elements[k].value.trim());
  const payload=Object.assign({},d,{consentimento:true,enviado_em:new Date().toISOString(),pagina:location.href.split('#')[0],origem_resumo:ol||'(direto)',origem:tracking,user_agent:navigator.userAgent});
  if(!CONFIG.formEndpoint){showDone('whatsapp',d);try{sessionStorage.removeItem('cgw_form_draft')}catch(x){}return}
  setLoading(true);
  try{
    const ctrl=new AbortController(), to=setTimeout(()=>ctrl.abort(),15000);
    const res=await fetch(CONFIG.formEndpoint,{method:'POST',headers:Object.assign({'Content-Type':'application/json','Accept':'application/json'},CONFIG.endpointHeaders),body:JSON.stringify(payload),signal:ctrl.signal});
    clearTimeout(to);
    if(!res.ok)throw new Error('HTTP '+res.status);
    try{sessionStorage.removeItem('cgw_form_draft')}catch(x){}
    if(window.dataLayer)window.dataLayer.push({event:'generate_lead',lead_necessidade:d.necessidade,lead_origem:ol||'direto'});
    showDone('sent',d);
  }catch(err){
    fStatus.textContent='Não conseguimos enviar agora. ';
    const a=document.createElement('a');a.href=waUrl(buildSummary(d));a.target='_blank';a.rel='noopener';a.textContent='Envie pelo WhatsApp';
    fStatus.append(a,' ou tente novamente em instantes.');
  }finally{setLoading(false)}
});
})();
